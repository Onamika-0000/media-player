package com.example.music;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import  androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MusicListAdapter  extends RecyclerView.Adapter<MusicListAdapter.viewHolder>{
    ArrayList<AudioModel>songsList;
    Context Context;

    public MusicListAdapter(ArrayList<AudioModel> songsList, android.content.Context context) {
        this.songsList = songsList;
        Context = context;
    }

    @Override
    public viewHolder onCreateViewHolder( ViewGroup parent, int viewType) {

        android.content.Context context;
        View view= LayoutInflater.from(Context).inflate(R.layout.recycler_item,parent,false);
        return new MusicListAdapter.viewHolder(view);
    }

    @Override
    public void onBindViewHolder(MusicListAdapter. viewHolder holder, @SuppressLint("RecyclerView") int position){

        AudioModel songData=songsList.get(position);
        holder.titleTextView.setText(songData.getTitle());
        if (MyMediaPlayer.currentIndex==position){
            holder.titleTextView.setTextColor(Color.parseColor("#FF0000"));
        }else {
            holder.titleTextView.setTextColor(Color.parseColor("#000000"));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //navigate to another acitivty
                MyMediaPlayer.getInstance().reset();
                MyMediaPlayer.currentIndex=position;
                Intent intent=new Intent(Context,MusicPlayerActivity.class);
                intent.putExtra("LIST",songsList);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                Context.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return songsList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder{
        TextView titleTextView;
        ImageView iconImageView;

        public viewHolder(View itemview){
            super(itemview);
            titleTextView=itemview.findViewById(R.id.music_title_test);
            iconImageView=itemview.findViewById(R.id.icon_view);
        }
    }
}

